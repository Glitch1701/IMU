#ifndef tl
#define tl

#if(ARDUINO >= 100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

class IMU_functions
{
  // Public functions
  public: 
  // Constructors
  IMU_functions(bool displayMsg=false);

  // Methods
  int libtest2();
  int calculateForce(); // Input weight and acceleration, output force

  // private functions
  private:
};

#endif
