#include "IMU_functions.h"

IMU_functions::IMU_functions(bool displayMsg)
{
  
}

// All functions
int libtest2()
{
  int rnd = random(0,10);
  return rnd;
}

int calculateForce(int weight, int acc) // Calculate force in any direction 
{
  int force = weight*acc;
  return force;
}

int calculateMovementX(int x) // Find out distance moved in X direction 
{
  int xDistance;
  return xDistance;
}

int calculateMovementY(int y) // Find out distance moved in Y direction 
{
  int yDistance;
  return yDistance;
}

int calculateMovementZ(int z) // Find out distance moved in Z direction 
{
  int zDistance;
  return zDistance;
}
