#include "BLE_functions.h"

BLE_functions::BLE_functions(bool displayMsg)
{
  
}

// All functions
int libtest()
{
  int rnd = random(0,10);
  return rnd;
}
