#ifndef tl
#define tl

#if(ARDUINO >= 100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

class BLE_functions
{
  // Public functions
  public: 
  // Constructors
  BLE_functions(bool displayMsg=false);

  // Methods
  int libtest();
  

  // private functions
  private:
};

#endif
